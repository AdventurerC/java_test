package records;
import java.io.*;

abstract public class BaseInputParser{
    public BaseInputParser(){ }

    public Table extractTable(String fileName) throws IOException,FileNotFoundException{
        return null;
    }
}



