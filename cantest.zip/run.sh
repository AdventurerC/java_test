:

java -classpath "build/;dist/lib/*;lib/*" records.RecordMerger $*

